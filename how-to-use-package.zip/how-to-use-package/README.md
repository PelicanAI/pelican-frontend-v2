# How to Use Page Package

## Installation

1. Copy folders to your project:
   - `app/(marketing)/how-to-use/` → your `app/(marketing)/` directory
   - `components/how-to-use/` → your `components/` directory
   - `public/demos/how-to-use/` → your `public/demos/` directory (create demos folder if needed)

2. Add "How to Use" link to your navigation in `/app/(marketing)/page.tsx`:

   Find the navigation section and add:
   ```jsx
   <Link href="/how-to-use">
     How to Use
   </Link>
   ```

   Add it between FEATURES and TEAM links.

3. Restart dev server: `npm run dev`

4. Test: Navigate to /how-to-use

## Files Included

- `app/(marketing)/how-to-use/page.tsx` - Main page component
- `app/(marketing)/how-to-use/how-to-use.css` - Page-specific styles
- `components/how-to-use/DemoCard.tsx` - Demo card component
- `components/how-to-use/DemoVideoPlaceholder.tsx` - Iframe wrapper for HTML demos
- `components/how-to-use/SkillBadge.tsx` - Beginner/Intermediate/Advanced badges
- `public/demos/how-to-use/*.html` - 6 animated demo videos
- `public/demos/how-to-use/pelican-logo*.png` - Logo files for demos

## No Additional Dependencies

Uses existing project packages only (React, Next.js, lucide-react).
